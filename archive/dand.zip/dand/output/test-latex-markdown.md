Title: test latex markdown
Tags: 数据分析初级,实战项目
Date: 2018-09-16

$$
J(\theta) = \frac 1 2 \sum_{i=1}^m (h_\theta(x^{(i)})-y^{(i)})^2
$$

- 测试测试 $\frac{x+y}{2}$ 测试测试