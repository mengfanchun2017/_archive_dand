Title: W10 Plus A/B测试数据清理提示
Tags: 数据分析初级,实战项目
Date: 2018-11-02

[TOC]

# /目标6/ 项目：分析A/B测试结果

## / 1.准备

最后一个项目，我们试一个新的节奏，每周学习完成之后，直接把项目的相关内容写完。所以呢，和以前的项目相同，首先请大家决定是在workspace做项目还是本地做，如果本地做的话，我传送了项目的两个数据文件和jupyter notebook的打包文件，在导学的最后链接。

## / 2.完成项目的 I-概率 部分的撰写

根据模版，这个部分完全是项目3中的清理内容为主，大家High起来一鼓作气搞定它！一定要开工哦（助教大大坏笑脸），有几点提醒：

- 这部分对于pandas数据的筛选使用比较凶残、计算数量时可以使用.shape[0], 也可以使用count， 也可以用len
- 独立用户使用.nunique()

### // 问题1，基本信息
代码如下，前面是小节号：

```python
# b. 使用下面的单元格来查找数据集中的行数。
print(len(df))
#使用len可以看出共多少行
print(df.count())
#使用count可以看到每列多少（可以观察到空数据）
#可以加参数见
#https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.count.html
df.shape[0]

# c. 数据集中独立用户的数量。
df.nunique()
```

到了下一问，用户转化比例就可以用转化了的用户处以总用户，用筛选加count检查不一样的次数，用isnull().sum()检查是否有缺失值：

```python
# d. 用户转化的比例
df['converted'].sum() / df['user_id'].nunique()

# e.  new_page 与 treatment 不一致的次数
df[(df['landing_page']=='new_page')&(df['group']!='treatment')].shape[0]

# f. 是否有任何行存在缺失值
df.isnull().sum()
```

### // 问题2，处理异常值

这里的重点是使用好过滤，并且能求比率：

```python
# a. 现在，使用测试题的答案创建一个符合测试规格要求的新数据集。将新 dataframe 存储在 df2 中。
# 先看下有多少这样的值
# 检查1看左边是newpage右边不是treatment的
dismatch1 = df[(df['landing_page']=='new_page')&(df['group']!='treatment')]
dismatch1.shape[0]

>>> 1928

# 检查2看左边不是newpage但是右边是treatment的
dismatch2 = df[(df['landing_page']!='new_page')&(df['group']=='treatment')]
dismatch2.shape[0]

>>> 1965

# 计算下比率
dismatchr = (dismatch1.shape[0] + dismatch2.shape[0]) / df.shape[0]
dismatchr

>>> 0.013220002852505111

# 发现只有1.3%的数据是这样的，但是回头想一想，应该看dismatch的是和match的比较
# 注意复杂过滤的写法，把每个条件放到（）中
match = df[(df['landing_page']=='new_page')&(df['group']=='treatment')].shape[0]
dismatchr2 = (dismatch1.shape[0] + dismatch2.shape[0]) / match
dismatchr2

>>> 0.026790814184748574

# 2.6%（上面计算出不一致的数据），不算太多，丢弃吧
# 建立df2，把符合要求的数据行过滤出来
df2 = df[((df['landing_page']=='new_page')&(df['group']=='treatment'))|((df['landing_page']=='old_page')&(df['group']=='control'))]
# 右侧df[()]中括号里面是过滤条件，可以符合
# 比如()&()代表与，&替换成|代表或
# 可以嵌套，如上面代码是两边先与，结果再求或
df2.shape[0]

>>> 290585

# 检查下是否数量相同
df2.shape[0] + dismatch1.shape[0] + dismatch2.shape[0] == df.shape[0]

>>> True

# 这样检查也可以
df2[((df2['group'] == 'treatment') == (df2['landing_page'] == 'new_page')) == False].shape[0]

>>> 0
```

### // 问题3，删除重复值

同样罗列在下面，一定要看懂自己写出来不要copy paste：

```python
# b. df2 中有一个重复的 user_id 。它是什么？
# .duplicated()就是输出重复行
df2[df2['user_id'].duplicated()]

# d. 删除 一个 含有重复的 user_id 的行， 但需要确保你的 dataframe 为 df2。
# 在小括弧中使用[]参数定义要判断deplicates的列
# 不加的话就是每列都重复才删除
df2 = df2.drop_duplicates(['user_id'])
df2.shape[0]
```

### // 问题4，计算比率

```python
# a. 不管它们收到什么页面，单个用户的转化率是多少？
# 使用转化的除总数
converte_rate = df2['converted'].sum() / df2.shape[0]
# converte因为是0、1区分，所以sum就是个数
# 使用round保留4位小数
round(convert_rate,4)

# b. 假定一个用户处于 control 组中，他的转化率是多少？
# c. 假定一个用户处于 treatment 组中，他的转化率是多少？
# 还是使用筛选解决，大家自己试一下

# d. 一个用户收到新页面的概率是多少？
# 也可以直接筛选出来shape转成数字计算
newpage_rate = df2[df2['landing_page'] == 'new_page'].shape[0] / df2.shape[0]
# 之后用round将结果保留4位小数
round(newpage_rate,4)
```

在这之后，不要忘了还有e的主观问题。这第一部分就做完了，基本上是上一个项目中加简单的比例计算，大家做好后就可以准备后两个部分的重点内容了，加油！

# /彩蛋/

也一并附上项目4文件打包：[/项目数据文件/](https://github.com/mengfanchun2017/DAND-Basic/blob/master/Project4/p4files.zip)






